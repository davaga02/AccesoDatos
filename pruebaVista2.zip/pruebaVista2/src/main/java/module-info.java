module com.example.pruebavista2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.xml;


    opens com.example.pruebavista2 to javafx.fxml;
    exports com.example.pruebavista2;
}