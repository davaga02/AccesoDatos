package com.example.pruebavista2;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ApoyoXML {

    List<FutbolistasPOJO> listaFutbolistas = new ArrayList<>();

    public void leerXML(String path) throws ParserConfigurationException, IOException, SAXException {

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dbBuilder = dbFactory.newDocumentBuilder();
        Document document = dbBuilder.parse(new File(path));

        Element raiz = document.getDocumentElement();
        System.out.println("Contenido XML " + raiz.getNodeName() + ":");
        NodeList nodeList = document.getElementsByTagName("alumno");

        for (int i=0;i<nodeList.getLength();i++){
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE){
                Element eElement = (Element) node;

                FutbolistasPOJO futbolista = new FutbolistasPOJO();
                futbolista.setId(Integer.parseInt(eElement.getAttribute("id")));
                futbolista.setNombre(eElement.getElementsByTagName("nombre").item(0).getTextContent());
                futbolista.setEquipo(eElement.getElementsByTagName("equipo").item(0).getTextContent());
                futbolista.setAnyo(Integer.parseInt(eElement.getElementsByTagName("año").item(0).getTextContent()));
                futbolista.setPosicion(eElement.getElementsByTagName("posicion").item(0).getTextContent());
                listaFutbolistas.add(futbolista);
            }
        }
    }

    public FutbolistasPOJO Read(int index){
        return listaFutbolistas.get(index);
    }

    public void Delete(int index){
        listaFutbolistas.remove(index);
    }

    public void Create(String nombre, String equipo, int anyo, String posicion ){
        FutbolistasPOJO nuevo = new FutbolistasPOJO();

        nuevo.setId(listaFutbolistas.size());
        nuevo.setNombre(nombre);
        nuevo.setEquipo(equipo);
        nuevo.setAnyo(anyo);
        nuevo.setPosicion(posicion);

        listaFutbolistas.add(nuevo);
    }

    public void update(Integer position, String nombre, String equipo, int anyo, String posicion  ){
        //listaNotas.get(position).setID(id);
        listaFutbolistas.get(position).setNombre(nombre);
        listaFutbolistas.get(position).setEquipo(equipo);
        listaFutbolistas.get(position).setAnyo(anyo);
        listaFutbolistas.get(position).setPosicion(posicion);
    }

    public int registros(){
        return listaFutbolistas.size();
    }

    public void EscribirXML(String path) throws TransformerConfigurationException, TransformerException, ParserConfigurationException{
        // Crear un documento XML vacío
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.newDocument();

        // Crear el elemento raíz
        Element rootElement = doc.createElement("futbolistas");
        doc.appendChild(rootElement);

        for (FutbolistasPOJO futbolista: listaFutbolistas ){


            // Agregar elementos y datos al documento
            Element childElement = doc.createElement("futbolista");
            childElement.setAttribute("id", String.valueOf(futbolista.getId()));

            // Agregamos bicicleta con ID=1 al root Bicicletas
            rootElement.appendChild(childElement);


            // Agregar elementos dentro de bicicleta -> nombre
            Element nombre = doc.createElement("nombre");
            nombre.appendChild(doc.createTextNode(futbolista.getNombre()));
            childElement.appendChild(nombre);

            // Agregar elementos dentro de bicicleta -> equipo
            Element equipo = doc.createElement("equipo");
            equipo.appendChild(doc.createTextNode(futbolista.getEquipo()));
            childElement.appendChild(equipo);

            // Agregar elementos dentro de bicicleta -> anyo
            Element anyo = doc.createElement("año");
            anyo.appendChild(doc.createTextNode(String.valueOf(futbolista.getAnyo())));
            childElement.appendChild(anyo);

            Element posicion = doc.createElement("posicion");
            posicion.appendChild(doc.createTextNode(String.valueOf(futbolista.getPosicion())));
            childElement.appendChild(posicion);


        }
        // Guardar el documento XML en un archivo
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();

        // Formateamos el fichero XML
        Properties outputProperties = new Properties();

        // Aquí marcamos que la tabulación debe ser de 4 espacios
        outputProperties.setProperty("{http://xml.apache.org/xslt}indent-amount", "4");

        // Aquí marcamos que queremos la tabulación
        outputProperties.setProperty(OutputKeys.INDENT, "yes");

        // Aquí marcamos que queremos la inicialización del archivo XML
        outputProperties.setProperty(OutputKeys.OMIT_XML_DECLARATION, "no");

        // Aplicamos las propiedades del fichero XML
        transformer.setOutputProperties(outputProperties);  // Opcional: dar formato al archivo

        // Especifica la ruta del archivo en el que deseas guardar el XML
        File xmlFile = new File(path);

        // Guarda el documento XML en el archivo especificado
        Result output = new StreamResult(xmlFile);
        transformer.transform(new DOMSource(doc), output);

        System.out.println("Archivo XML generado correctamente.");
    }

}

