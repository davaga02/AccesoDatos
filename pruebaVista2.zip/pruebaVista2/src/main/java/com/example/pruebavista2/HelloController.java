package com.example.pruebavista2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.URL;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class HelloController implements Initializable {


    @FXML
    public Button buttonNext;
    @FXML
    public Button buttonPrevious;
    @FXML
    public TextField fieldEquipo;
    @FXML
    public TextField fieldAnyo;
    @FXML
    public TextField fieldPosicion;
    @FXML
    public TextField fieldINombre;
    @FXML
    public Text textViewId;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        ApoyoXML ap = new ApoyoXML();

        try {
            ap.leerXML("futbolistas.xml");

            for (FutbolistasPOJO futbolista: ap.listaFutbolistas){

                textViewId.setText(String.valueOf(futbolista.getId()));
                fieldINombre.setText(futbolista.getNombre());
                fieldEquipo.setText(futbolista.getEquipo());
                fieldAnyo.setText(String.valueOf(futbolista.getAnyo()));
                fieldPosicion.setText(futbolista.getPosicion());
            }

        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        }


    }

    @FXML
    public void handleButtonActionNext(ActionEvent actionEvent) {
    }

    @FXML
    public void handleButtonActionPrevios(ActionEvent actionEvent) {
    }

    @FXML
    public void handleButtonActionCreate(ActionEvent actionEvent) {
    }

    @FXML
    public void handleButtonActionDelete(ActionEvent actionEvent) {
    }

    @FXML
    public void handleButtonActionUpdate(ActionEvent actionEvent) {
    }


}