package com.example.listaaccedat;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GestionarXML {

    List<FutbolistaPOJO> futbolistas = new ArrayList<>();

    public List<FutbolistaPOJO> LeerXML(String path) throws SAXException, ParserConfigurationException, IOException {
        futbolistas.clear();
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dbBuilder = dbFactory.newDocumentBuilder();
        Document document = dbBuilder.parse(new File(path));

        Element raiz = document.getDocumentElement();
        NodeList nodeList = document.getElementsByTagName("futbolista");

        for (int i=0;i<nodeList.getLength();i++){
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE){
                Element eElement = (Element) node;
                FutbolistaPOJO futbolista = new FutbolistaPOJO();
                futbolista.setId(Integer.parseInt(eElement.getAttribute("id")));
                futbolista.setNombre(eElement.getElementsByTagName("nombre").item(0).getTextContent());
                futbolista.setEquipo(eElement.getElementsByTagName("equipo").item(0).getTextContent());
                futbolista.setAño(Integer.parseInt(eElement.getElementsByTagName("anyo").item(0).getTextContent()));
                futbolista.setPosicion(eElement.getElementsByTagName("posicion").item(0).getTextContent());
                futbolistas.add(futbolista);
            }
        }

        return futbolistas;
    }


}
