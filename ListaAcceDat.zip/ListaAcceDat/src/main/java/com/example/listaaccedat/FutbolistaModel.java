package com.example.listaaccedat;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class FutbolistaModel extends Conexion{

    public ArrayList<FutbolistaPOJO> listar_futbolistas(){
        ArrayList<FutbolistaPOJO> lista = new ArrayList<>();
        try {
            String sql = "Select * from jugadores";
            PreparedStatement ps = this.getConexion().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                FutbolistaPOJO p =  new FutbolistaPOJO(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(5),rs.getString(4));
                lista.add(p);
            }

            rs.close();
            ps.close();
            this.cerrarConexion();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return lista;
    }

    public boolean eliminar_futbolista(int id){
        boolean resultado = false;

        try {
            String sql = "delete from jugadores where id = ?";
            PreparedStatement ps = this.getConexion().prepareStatement(sql);
            ps.setInt(1,id);
            ps.execute();
            resultado = true;

            ps.close();
            this.cerrarConexion();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return resultado;
    }

    public boolean crear_futbolista(FutbolistaPOJO fp){
        boolean resultado = false;

        try {
            String sql = " INSERT INTO Jugadores (nombre, equipo, posicion, anio_nacimiento) VALUES (?,?,?,?)";
            PreparedStatement ps = this.getConexion().prepareStatement(sql);
            ps.setString(1,fp.getNombre());
            ps.setString(2,fp.getEquipo());
            ps.setString(3,fp.getPosicion());
            ps.setInt(4,fp.getAño());
            ps.execute();
            resultado = true;

            ps.close();
            this.cerrarConexion();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return resultado;
    }

    public boolean actualizar_futbolista(FutbolistaPOJO fp){
        boolean resultado = false;

        try {
            String sql = " UPDATE Jugadores SET nombre = ?, equipo = ?, posicion = ?, anio_nacimiento = ? WHERE id = ?;";
            PreparedStatement ps = this.getConexion().prepareStatement(sql);
            ps.setString(1,fp.getNombre());
            ps.setString(2,fp.getEquipo());
            ps.setString(3,fp.getPosicion());
            ps.setInt(4,fp.getAño());
            ps.setInt(5,fp.getId());
            ps.execute();
            resultado = true;

            ps.close();
            this.cerrarConexion();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return resultado;
    }

}
