package com.example.listaaccedat;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Button buttonNext;
    @FXML
    private Label label;
    @FXML
    private Button buttonPrevious;
    @FXML
    private TextField nombrefield;
    @FXML
    private TextField equipofield;
    @FXML
    private TextField añofield;
    @FXML
    private Text idtext;
    @FXML
    private TextField posicionfield;

    private GestionarXML gx;
    private FutbolistaModel fm;
    int posicion;
    boolean crear = false;
    FutbolistaPOJO fpant;
    FutbolistaPOJO fpant2;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        fpant = new FutbolistaPOJO();
        fpant2 = new FutbolistaPOJO();
        gx = new GestionarXML();
        fm = new FutbolistaModel();
        posicion = 0;

        FutbolistaPOJO fp = fm.listar_futbolistas().get(posicion);
        idtext.setText(idtext.getText() + fp.getId());
        nombrefield.setText(fp.getNombre());
        equipofield.setText(fp.getEquipo());
        añofield.setText(String.valueOf(fp.getAño()));
        posicionfield.setText(fp.getPosicion());
    }

    @FXML
    public void handleButtonActionNext(ActionEvent actionEvent) throws ParserConfigurationException, IOException, SAXException {

        if (posicion < (fm.listar_futbolistas().size()-1)) {
            fpant2 = fm.listar_futbolistas().get(posicion);
        }
        actualizar();

        if (nombrefield.getText().isBlank() && posicion <= (fm.listar_futbolistas().size() - 1) && !crear) {
            eliminado();
        } else if (posicion < (fm.listar_futbolistas().size() - 1)) {
            posicion++;
            idtext.setText("FUTBOLISTA: ");
            FutbolistaPOJO fp = fm.listar_futbolistas().get(posicion);
            idtext.setText(idtext.getText() + fp.getId());
            nombrefield.setText(fp.getNombre());
            equipofield.setText(fp.getEquipo());
            añofield.setText(String.valueOf(fp.getAño()));
            posicionfield.setText(fp.getPosicion());
        } else if (posicion == (fm.listar_futbolistas().size()-1) || posicion == fm.listar_futbolistas().size()){
            creado();
        }else{
            Alert a = new Alert(Alert.AlertType.ERROR,"no hay siguiente");
            a.show();
        }
    }

    @FXML
    public void handleButtonActionPrevios(ActionEvent actionEvent) {

        if (posicion < (fm.listar_futbolistas().size() - 1)) {
            fpant2 = fm.listar_futbolistas().get(posicion);
        }
        actualizar();

        if (nombrefield.getText().isBlank() && !crear) {
            eliminado();
        }else if (posicion > 0 && posicion < (fm.listar_futbolistas().size() - 1)) {
            posicion--;
            idtext.setText("FUTBOLISTA: ");
            FutbolistaPOJO fp = fm.listar_futbolistas().get(posicion);
            idtext.setText(idtext.getText() + fp.getId());
            nombrefield.setText(fp.getNombre());
            equipofield.setText(fp.getEquipo());
            añofield.setText(String.valueOf(fp.getAño()));
            posicionfield.setText(fp.getPosicion());
        }else if (posicion == (fm.listar_futbolistas().size()-1) || posicion == fm.listar_futbolistas().size()){
            creado();
        }else{
            Alert a = new Alert(Alert.AlertType.ERROR,"no hay previo");
            a.show();
        }
    }

    @FXML
    public void handleButtonActionCreate(ActionEvent actionEvent) {
    }

    @FXML
    public void handleButtonActionDelete(ActionEvent actionEvent) {
    }

    @FXML
    public void handleButtonActionUpdate(ActionEvent actionEvent) {
    }


    public void eliminado(){
        fm.eliminar_futbolista(fm.listar_futbolistas().get(posicion).getId());
        reiniciar();
    }

    public void creado(){

        if (crear) {
            String nombre = nombrefield.getText();
            String equipo = equipofield.getText();
            String pose = posicionfield.getText();
            int anyo = 0;
            if (añofield.getText().isBlank()){
                return;
            }
            anyo = Integer.valueOf(añofield.getText());
            FutbolistaPOJO cre = new FutbolistaPOJO(0, nombre, equipo, anyo, pose);
            if (!fpant.equals(cre)) {
                if (fm.crear_futbolista(cre)) {
                    Alert a = new Alert(Alert.AlertType.INFORMATION, "Creado Correctamente");
                    a.show();
                    reiniciar();
                }
            }
            crear = false;
        }else{

            String nombre = nombrefield.getText();
            String equipo = equipofield.getText();
            String pose = posicionfield.getText();
            int anyo = Integer.valueOf(añofield.getText());
            fpant = new FutbolistaPOJO(0, nombre, equipo, anyo, pose);

            idtext.setText("FUTBOLISTA: ");
            nombrefield.setText("");
            equipofield.setText("");
            añofield.setText("");
            posicionfield.setText("");
            posicion++;
            crear = true;
        }


    }

    public void actualizar(){
        if ((fm.listar_futbolistas().size()) <= posicion)return;
        String nombre = nombrefield.getText();
        String equipo = equipofield.getText();
        String pose = posicionfield.getText();
        if (añofield.getText().isBlank()){return;}
        int anyo = Integer.valueOf(añofield.getText());
        FutbolistaPOJO actu = new FutbolistaPOJO(fm.listar_futbolistas().get(posicion).getId(), nombre, equipo, anyo, pose);
        if (!fpant2.equals(actu)) {
            System.out.println("No iguales");
            fm.actualizar_futbolista(actu);
        }
        System.out.println("Iguales");
        System.out.println(fpant2.toString());
        System.out.println(actu.toString());


    }

    public void reiniciar(){
        idtext.setText("FUTBOLISTA: ");
        posicion=0;
        FutbolistaPOJO fp = fm.listar_futbolistas().get(posicion);
        idtext.setText(idtext.getText() + fp.getId());
        nombrefield.setText(fp.getNombre());
        equipofield.setText(fp.getEquipo());
        añofield.setText(String.valueOf(fp.getAño()));
        posicionfield.setText(fp.getPosicion());
    }

}