package com.example.listaaccedat;

import java.util.Objects;

public class FutbolistaPOJO {

    private int id;
    private String nombre;
    private String equipo;
    private int año;
    private String posicion;

    public FutbolistaPOJO() {
    }

    public FutbolistaPOJO(int id, String nombre, String equipo, int año, String posicion) {
        this.id = id;
        this.nombre = nombre;
        this.equipo = equipo;
        this.año = año;
        this.posicion = posicion;
    }

    @Override
    public String toString() {
        return "FutbolistaPOJO{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", equipo='" + equipo + '\'' +
                ", año=" + año +
                ", posicion='" + posicion + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FutbolistaPOJO that = (FutbolistaPOJO) o;
        return año == that.año && Objects.equals(nombre, that.nombre) && Objects.equals(equipo, that.equipo) && Objects.equals(posicion, that.posicion);
    }
}
